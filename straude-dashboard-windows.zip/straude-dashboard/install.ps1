# Instalador del Straude Dashboard (Windows).
# Uso: doble clic en Instalar.bat  (o: powershell -ExecutionPolicy Bypass -File install.ps1)
# Cada paso se verifica antes de seguir; si algo falla se detiene y lo explica.

$ErrorActionPreference = 'Stop'
$Src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = Join-Path $env:USERPROFILE 'straude-dash'
$Port = 8934

function Step($n, $msg) { Write-Host ""; Write-Host "==> [$n] $msg" -ForegroundColor Cyan }
function Ok($msg)       { Write-Host "    OK: $msg" -ForegroundColor Green }
function Warn($msg)     { Write-Host "    AVISO: $msg" -ForegroundColor Yellow }
function Fail($msg) {
    Write-Host "    ERROR: $msg" -ForegroundColor Red
    Write-Host ""
    Read-Host "Presiona Enter para cerrar"
    exit 1
}

function Refresh-Path {
    # winget modifica el PATH en el registro, pero esta ventana no se entera sola.
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

function Have-Winget { [bool](Get-Command winget -ErrorAction SilentlyContinue) }

function Winget-Install($id) {
    if (-not (Have-Winget)) { Fail "No encontre winget para instalar $id. Instalalo a mano y volve a correr este instalador." }
    winget install -e --id $id --silent --accept-package-agreements --accept-source-agreements
    Refresh-Path
}

function Node-Major {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if (-not $node) { return 0 }
    $v = (& node -v) -replace '^v', ''
    return [int]($v.Split('.')[0])
}

function Find-Python {
    # Devuelve la ruta completa a python.exe (3.10+) o $null.
    # Se ignora el "python" falso de WindowsApps (abre la Microsoft Store).
    $tries = @()
    if (Get-Command py -ErrorAction SilentlyContinue) { $tries += ,@('py', '-3') }
    $p = Get-Command python -ErrorAction SilentlyContinue
    if ($p -and $p.Source -notlike '*\WindowsApps\*') { $tries += ,@($p.Source) }
    foreach ($t in $tries) {
        try {
            $exe = $t[0]; $args2 = @($t | Select-Object -Skip 1)
            $out = & $exe @args2 -c "import sys; print(sys.executable if sys.version_info >= (3, 10) else '')" 2>$null
            if ($LASTEXITCODE -eq 0 -and $out -and (Test-Path $out)) { return $out.Trim() }
        } catch { }
    }
    return $null
}

Write-Host "STRAUDE DASHBOARD - instalador para Windows" -ForegroundColor White
Write-Host "Origen: $Src"
Write-Host "Destino: $Dest"

# ---------------------------------------------------------------- 1. Requisitos
Step 1 "Verificando Node.js 20+ y Python 3.10+"
$major = Node-Major
if ($major -lt 20) {
    if ($major -eq 0) { Warn "Node.js no esta instalado. Instalando con winget..." }
    else { Warn "Node.js v$major es viejo (hace falta 20+). Instalando LTS con winget..." }
    Winget-Install 'OpenJS.NodeJS.LTS'
    $major = Node-Major
    if ($major -lt 20) { Fail "Node.js sigue sin estar disponible. Cerra esta ventana, abri una nueva y volve a correr el instalador." }
}
Ok "Node.js $(& node -v)"

$Py = Find-Python
if (-not $Py) {
    Warn "Python 3.10+ no esta instalado. Instalando Python 3.12 con winget..."
    Winget-Install 'Python.Python.3.12'
    $Py = Find-Python
    if (-not $Py) {
        # winget instala por usuario en esta ruta; puede no estar en PATH todavia
        $guess = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
        if (Test-Path $guess) { $Py = $guess }
    }
    if (-not $Py) { Fail "Python sigue sin estar disponible. Cerra esta ventana, abri una nueva y volve a correr el instalador." }
}
$PyW = Join-Path (Split-Path $Py) 'pythonw.exe'
if (-not (Test-Path $PyW)) { $PyW = $Py }
Ok "Python $(& $Py -c 'import sys; print(sys.version.split()[0])')  ($Py)"

# ---------------------------------------------------------------- 2. npm global
Step 2 "Instalando ccusage y straude (npm install -g)"
& npm.cmd install -g ccusage straude
if ($LASTEXITCODE -ne 0) { Fail "npm install -g ccusage straude fallo (mira el mensaje de arriba)." }
Refresh-Path
$npmPrefix = Join-Path $env:APPDATA 'npm'
if ($env:Path -notlike "*$npmPrefix*") { $env:Path = "$npmPrefix;$env:Path" }
$cc = Get-Command ccusage -ErrorAction SilentlyContinue
if (-not $cc) { Fail "ccusage se instalo pero no aparece en el PATH ($npmPrefix)." }
Ok "ccusage en $($cc.Source)"

# ---------------------------------------------------------------- 3. Copia
Step 3 "Copiando archivos a $Dest"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
$files = 'build_dashboard.py','extract_data.py','extract_desktop_conversations.py','server.py',
         'template.html','launcher.pyw','start.bat','refresh.bat','LEEME.txt',
         'diagnostico.py','diagnostico.bat'
foreach ($f in $files) {
    $from = Join-Path $Src $f
    if (-not (Test-Path $from)) { Fail "Falta el archivo $f en la carpeta del instalador." }
    if ((Resolve-Path $Src).Path -ne (Resolve-Path $Dest).Path) { Copy-Item $from $Dest -Force }
}
Get-ChildItem $Dest | Unblock-File -ErrorAction SilentlyContinue   # quita la marca "descargado de internet"
Ok "$($files.Count) archivos en $Dest"

# ---------------------------------------------------------------- 4. (ya adaptado)
Step 4 "Codigo adaptado a Windows"
Ok "extract_data.py, extract_desktop_conversations.py y server.py ya vienen adaptados"

# ---------------------------------------------------------------- 5. venv opcional
Step 5 "(Opcional) venv para leer conversaciones de Claude Desktop"
Write-Host "    (sesiones de Claude Code / Cowork lanzadas desde la app y corridas en la nube)"
$venv = Join-Path $Dest '.venv-chatextract'
# Se instala desde el zip de GitHub: no hace falta tener git.
$cclZip = 'https://github.com/cclgroupltd/ccl_chromium_reader/archive/refs/heads/master.zip'
try {
    if (-not (Test-Path (Join-Path $venv 'Scripts\python.exe'))) {
        & $Py -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw "venv" }
    }
    $vpy = Join-Path $venv 'Scripts\python.exe'
    & $vpy -m pip install -q --upgrade $cclZip
    if ($LASTEXITCODE -ne 0 -and (Get-Command git -ErrorAction SilentlyContinue)) {
        & $vpy -m pip install -q --upgrade 'git+https://github.com/cclgroupltd/ccl_chromium_reader.git'
    }
    & $vpy -c "import ccl_chromium_reader.ccl_chromium_indexeddb"
    if ($LASTEXITCODE -ne 0) { throw "pip" }
    Ok "ccl_chromium_reader instalado en .venv-chatextract"
} catch {
    Warn "No se pudo instalar ccl_chromium_reader: las sesiones de Claude Desktop / nube no se van a ver."
}

# ---------------------------------------------------------------- 6. Pruebas
Step 6 "Probando: extract_data.py -> build_dashboard.py -> server.py"
# Si ya habia un server corriendo (instalacion anterior), se cierra para
# que arranque con el codigo nuevo.
$old = Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue |
       Where-Object { $_.CommandLine -like '*straude-dash*server.py*' }
foreach ($p in $old) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
if ($old) { Ok "Server anterior cerrado ($(@($old).Count) proceso/s)"; Start-Sleep -Seconds 1 }
Push-Location $Dest
$env:DO_NOT_TRACK = '1'
& $Py extract_data.py
if ($LASTEXITCODE -ne 0) { Pop-Location; Fail "extract_data.py fallo (mira el mensaje de arriba)." }
$data = Get-Content (Join-Path $Dest 'data.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Ok "data.json con $($data.sessions.Count) sesiones"
& $Py build_dashboard.py
if ($LASTEXITCODE -ne 0) { Pop-Location; Fail "build_dashboard.py fallo." }
Ok "dashboard.html generado"
Pop-Location

function Api-Data {
    try { return Invoke-RestMethod -Uri "http://localhost:$Port/api/data" -TimeoutSec 2 } catch { return $null }
}
if (-not (Api-Data)) {
    Write-Host "    Levantando server.py en segundo plano (la primera carga tarda ~20s)..."
    Start-Process -FilePath $PyW -ArgumentList "`"$(Join-Path $Dest 'launcher.pyw')`"" -WorkingDirectory $Dest
}
$api = $null
for ($i = 0; $i -lt 90 -and -not $api; $i++) { Start-Sleep -Seconds 1; $api = Api-Data }
if (-not $api) { Fail "El server no respondio en http://localhost:$Port/api/data. Log: $env:TEMP\straude-dashboard.log" }
$cost = [math]::Round([double]$api.totals.totalCost, 2)
Ok "http://localhost:$Port/api/data responde: $($api.sessions.Count) sesiones, costo total USD $cost"
if ($api.sessions.Count -eq 0) {
    Warn "No hay sesiones todavia: aparecen cuando uses Claude Code / Codex en esta PC."
}

# ---------------------------------------------------------------- 7. Acceso directo
Step 7 "Creando acceso directo 'Straude Dashboard' en el Escritorio"
$desktop = [Environment]::GetFolderPath('Desktop')   # respeta Escritorio en OneDrive
$lnkPath = Join-Path $desktop 'Straude Dashboard.lnk'
$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut($lnkPath)
$lnk.TargetPath = $PyW
$lnk.Arguments = "`"$(Join-Path $Dest 'launcher.pyw')`""
$lnk.WorkingDirectory = $Dest
$lnk.Description = 'Abre el Straude Dashboard (http://localhost:8934)'
$lnk.IconLocation = "$PyW,0"
$lnk.Save()
if (-not (Test-Path $lnkPath)) { Fail "No se pudo crear el acceso directo." }
Ok $lnkPath

# ---------------------------------------------------------------- 8. Listo
Step 8 "Listo"
Write-Host "    El dashboard ya esta corriendo en http://localhost:$Port (se abrio en el navegador)."
Write-Host "    Para abrirlo otro dia: doble clic en 'Straude Dashboard' del Escritorio."
Write-Host "    Alternativas: start.bat (con ventana) o refresh.bat (snapshot sin server) en $Dest"
Write-Host ""
Write-Host "    Opcional - aparecer en straude.com: abri una terminal y corre:  straude" -ForegroundColor White
Write-Host "    (la primera vez abre el navegador para loguearte con tu cuenta)."
Write-Host ""
Read-Host "Presiona Enter para cerrar"
