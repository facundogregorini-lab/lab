@echo off
rem Modo snapshot (sin servidor): regenera dashboard.html con los datos de
rem ahora y lo abre. Para que se actualice solo, usa start.bat.
cd /d "%~dp0"
set DO_NOT_TRACK=1
set "PY=python"
where py >NUL 2>&1 && set "PY=py -3"
%PY% extract_data.py || goto :error
%PY% build_dashboard.py || goto :error
start "" "%~dp0dashboard.html"
exit /b 0
:error
echo Algo fallo. Revisa el mensaje de arriba.
pause
exit /b 1
