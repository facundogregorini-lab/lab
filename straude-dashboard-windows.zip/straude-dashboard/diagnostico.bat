@echo off
rem Muestra que fuentes de uso de Claude encuentra el dashboard en esta PC.
cd /d "%~dp0"
set DO_NOT_TRACK=1
set "PY=python"
where py >NUL 2>&1 && set "PY=py -3"
%PY% diagnostico.py
pause
