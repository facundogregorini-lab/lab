"""
Lanzador del acceso directo "Straude Dashboard" (equivalente Windows de
launcher.applescript). Se ejecuta con pythonw, así que no abre ninguna
ventana de consola.

- Si el server ya responde en http://localhost:8934 -> abre el navegador.
- Si no -> lanza server.py en segundo plano (pythonw, sin ventana). El server
  abre el navegador solo cuando termina la primera carga de datos.
  Los mensajes quedan en %TEMP%\\straude-dashboard.log.
"""
import os
import subprocess
import sys
import tempfile
import urllib.request
import webbrowser
from pathlib import Path

BASE = Path(__file__).resolve().parent
PORT = int(os.environ.get("DASHBOARD_PORT", "8934"))
URL = f"http://localhost:{PORT}/"


def server_responds():
    try:
        with urllib.request.urlopen(URL + "api/data", timeout=1) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def pythonw_executable():
    exe = Path(sys.executable)
    candidate = exe.with_name("pythonw.exe")
    return str(candidate if candidate.exists() else exe)


def main():
    if server_responds():
        webbrowser.open(URL)
        return
    flags = 0
    if os.name == "nt":
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    log_path = Path(tempfile.gettempdir()) / "straude-dashboard.log"
    with open(log_path, "a", encoding="utf-8") as log:
        subprocess.Popen(
            [pythonw_executable(), str(BASE / "server.py")],
            cwd=str(BASE),
            env=dict(os.environ, DO_NOT_TRACK="1", PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1"),
            stdin=subprocess.DEVNULL, stdout=log, stderr=log,
            creationflags=flags,
            close_fds=True,
        )


if __name__ == "__main__":
    main()
