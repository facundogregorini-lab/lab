@echo off
rem Doble clic para instalar el Straude Dashboard en Windows.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
