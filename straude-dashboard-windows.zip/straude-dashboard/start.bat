@echo off
rem Levanta el dashboard en vivo: http://localhost:8934
rem Deja esta ventana abierta mientras lo uses (Ctrl+C para cerrarlo).
cd /d "%~dp0"
set DO_NOT_TRACK=1
set "PY=python"
where py >NUL 2>&1 && set "PY=py -3"
%PY% server.py
pause
