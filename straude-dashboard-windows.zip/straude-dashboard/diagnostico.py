#!/usr/bin/env python3
"""
Diagnóstico: muestra qué fuentes de uso de Claude encuentra el dashboard en
esta PC y cuántas sesiones aporta cada una. Solo imprime conteos y rutas,
nunca contenido de conversaciones. El resultado queda también en
diagnostico.txt (para mandarlo si hace falta ayuda).
"""
import json
import os
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import extract_data as ed  # noqa: E402  (también arma el PATH con npm/node)
import extract_desktop_conversations as edc  # noqa: E402

lines = []


def out(msg=""):
    print(msg)
    lines.append(msg)


def section(title):
    out()
    out(f"== {title}")


def claude_code_local():
    section("1. Claude Code local (%USERPROFILE%\\.claude\\projects)")
    roots = []
    if os.environ.get("CLAUDE_CONFIG_DIR"):
        for p in os.environ["CLAUDE_CONFIG_DIR"].split(","):
            roots.append(Path(p.strip()) / "projects")
        out(f"CLAUDE_CONFIG_DIR = {os.environ['CLAUDE_CONFIG_DIR']}")
    roots += [ed.HOME / ".claude" / "projects", ed.HOME / ".config" / "claude" / "projects"]
    for r in roots:
        if not r.is_dir():
            out(f"  {r}: no existe")
            continue
        files = list(r.glob("*/*.jsonl"))
        newest = max((f.stat().st_mtime for f in files), default=None)
        newest_s = datetime.fromtimestamp(newest).strftime("%Y-%m-%d %H:%M") if newest else "-"
        out(f"  {r}: {len(files)} sesiones .jsonl (última: {newest_s})")


def ccusage():
    section("2. ccusage")
    try:
        cmd = ed.ccusage_command()
        out(f"  comando: {' '.join(cmd)}")
        raw = ed.run_ccusage_session_json(offline=True)
    except Exception as e:  # noqa: BLE001
        out(f"  ERROR corriendo ccusage: {e}")
        return
    sessions = raw.get("session", [])
    by_agent = Counter(s.get("agent", "?") for s in sessions)
    cost = Counter()
    no_date = Counter()
    for s in sessions:
        cost[s.get("agent", "?")] += s.get("totalCost", 0) or 0
        if not (s.get("metadata") or {}).get("lastActivity"):
            no_date[s.get("agent", "?")] += 1
    if not sessions:
        out("  ccusage no devolvió ninguna sesión.")
    for agent, n in by_agent.most_common():
        extra = f", {no_date[agent]} SIN FECHA (el dashboard las descarta)" if no_date[agent] else ""
        out(f"  {agent}: {n} sesiones, USD {cost[agent]:.2f}{extra}")


def claude_desktop():
    section("3. Claude Desktop / Code y Cowork en la nube (caché de la app)")
    out(f"  carpeta de la app: {edc.CLAUDE_APP_SUPPORT} ({'existe' if edc.CLAUDE_APP_SUPPORT.is_dir() else 'NO existe'})")
    leveldb = edc.IDB_LEVELDB
    if leveldb.is_dir():
        size = sum(f.stat().st_size for f in leveldb.iterdir() if f.is_file()) / 1e6
        out(f"  IndexedDB: existe ({size:.1f} MB)")
    else:
        out("  IndexedDB: NO existe (¿no usás la app de escritorio o está en otra ruta?)")
        idb_root = edc.CLAUDE_APP_SUPPORT / "IndexedDB"
        if idb_root.is_dir():
            out("  carpetas dentro de IndexedDB: " + ", ".join(p.name for p in idb_root.iterdir()))
    venv_dir = BASE / ".venv-chatextract"
    vpy = venv_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python3")
    if not vpy.exists():
        out("  venv .venv-chatextract: NO existe -> esta fuente está desactivada. Volvé a correr Instalar.bat.")
        return
    try:
        r = subprocess.run(
            [str(vpy), str(BASE / "extract_desktop_conversations.py")],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            env=dict(os.environ, PYTHONIOENCODING="utf-8"), timeout=120, creationflags=ed.NO_WINDOW,
        )
        sessions = json.loads(r.stdout) if r.returncode == 0 and r.stdout.strip() else []
        err = [l for l in r.stderr.splitlines() if l.strip()]
        out(f"  sesiones remotas encontradas: {len(sessions)}, USD {sum(s['totalCost'] for s in sessions):.2f}")
        for l in err[-5:]:
            out(f"  (log) {l}")
    except Exception as e:  # noqa: BLE001
        out(f"  ERROR corriendo el extractor: {e}")


def dashboard_data():
    section("4. Lo que ve el dashboard (junta todo)")
    try:
        data = ed.collect(offline=True)
    except Exception as e:  # noqa: BLE001
        out(f"  ERROR: {e}")
        return
    groups = Counter()
    cost = Counter()
    for s in data["sessions"]:
        groups[s["group"]] += 1
        cost[s["group"]] += s["totalCost"]
    if not groups:
        out("  0 sesiones.")
    for g, n in groups.most_common():
        out(f"  {g}: {n} sesiones, USD {cost[g]:.2f}")


if __name__ == "__main__":
    out(f"Diagnóstico Straude Dashboard - {datetime.now():%Y-%m-%d %H:%M}")
    out(f"Usuario: {ed.HOME}   Python {sys.version.split()[0]}")
    claude_code_local()
    ccusage()
    claude_desktop()
    dashboard_data()
    (BASE / "diagnostico.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    out()
    out(f"Guardado en {BASE / 'diagnostico.txt'}")
