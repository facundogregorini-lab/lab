#!/usr/bin/env python3
"""Inyecta data.json dentro de template.html -> dashboard.html (autocontenido)."""
import json
from pathlib import Path

BASE = Path(__file__).parent
data = json.loads((BASE / "data.json").read_text(encoding="utf-8"))
template = (BASE / "template.html").read_text(encoding="utf-8")

out = template.replace("__DASHBOARD_DATA__", json.dumps(data, separators=(",", ":")))
(BASE / "dashboard.html").write_text(out, encoding="utf-8")
print(f"Escrito {BASE / 'dashboard.html'} ({len(out)} bytes)")
